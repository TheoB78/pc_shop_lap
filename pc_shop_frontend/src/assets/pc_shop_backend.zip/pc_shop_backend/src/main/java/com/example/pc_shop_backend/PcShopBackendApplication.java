package com.example.pc_shop_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PcShopBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(PcShopBackendApplication.class, args);
	}

}
